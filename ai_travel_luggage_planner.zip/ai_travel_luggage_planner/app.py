import os
import math
from datetime import datetime
from io import BytesIO

import requests
from flask import Flask, render_template, request, send_file, url_for
from dotenv import load_dotenv
from reportlab.pdfgen import canvas
from reportlab.lib.pagesizes import A4
from reportlab.lib.units import mm
from reportlab.lib import colors

load_dotenv()

app = Flask(__name__)

ICON_MAP = {
    'T-shirt': 'tshirt.svg',
    'Shirt/Top': 'tshirt.svg',
    'Dress': 'dress.svg',
    'Jeans/Trousers': 'pants.svg',
    'Shorts': 'shorts.svg',
    'Underwear': 'underwear.svg',
    'Socks': 'socks.svg',
    'Sleepwear': 'sleep.svg',
    'Jacket/Coat': 'jacket.svg',
    'Sweater/Hoodie': 'hoodie.svg',
    'Raincoat/Poncho': 'raincoat.svg',
    'Scarf': 'scarf.svg',
    'Gloves': 'gloves.svg',
    'Cap/Hat': 'hat.svg',
    'Swimwear': 'swim.svg',
    'Flip-flops': 'flipflops.svg',
    'Walking Shoes': 'shoes.svg',
    'Dress Shoes/Heels': 'heels.svg',
    'Boots': 'boots.svg',
    'Sunscreen (SPF 30+)': 'sunscreen.svg',
    'Sunglasses': 'sunglasses.svg',
    'Umbrella': 'umbrella.svg',
    'Toothbrush': 'toothbrush.svg',
    'Toothpaste': 'toothpaste.svg',
    'Shampoo/Conditioner': 'bottle.svg',
    'Soap/Body Wash': 'soap.svg',
    'Deodorant': 'deodorant.svg',
    'Razor/Trimmer': 'razor.svg',
    'Makeup/Remover': 'makeup.svg',
    'Skincare': 'skincare.svg',
    'Medications': 'medicine.svg',
    'First-aid (Band-aids etc.)': 'firstaid.svg',
    'Sanitizer/Wipes': 'wipes.svg',
    'Tissues': 'tissues.svg',
    'Passport': 'passport.svg',
    'Government ID': 'id.svg',
    'Travel Tickets': 'ticket.svg',
    'Visa/Itinerary': 'visa.svg',
    'Cash & Cards': 'wallet.svg',
    'Travel Insurance': 'insurance.svg',
    'Power Bank': 'powerbank.svg',
    'Phone + Charger': 'phone.svg',
    'Laptop/Tablet + Charger': 'laptop.svg',
    'Camera + Batteries': 'camera.svg',
    'Universal Adapter': 'adapter.svg',
    'Cables/USB': 'cable.svg',
    'Backpack/Daypack': 'backpack.svg',
    'Luggage Locks': 'lock.svg',
    'Packing Cubes': 'cube.svg',
    'Reusable Bottle': 'bottle.svg',
    'Neck Pillow': 'pillow.svg',
    'Eye Mask/Earplugs': 'sleep.svg',
    'Jewelry (minimal)': 'jewelry.svg',
    'Belt': 'belt.svg',
    'Towel/Quick-dry': 'towel.svg',
    'Snacks': 'snack.svg',
}

TRIP_TYPES = ['leisure', 'business', 'beach', 'hiking', 'wedding', 'international']


def fetch_weather(location: str):
    """Fetch current weather for a location using OpenWeatherMap API.
    Returns (data, error)."""
    api_key = os.getenv('OPENWEATHER_API_KEY')
    if not api_key:
        return None, 'Missing OPENWEATHER_API_KEY. Set it in your environment or .env file.'
    try:
        resp = requests.get(
            'https://api.openweathermap.org/data/2.5/weather',
            params={'q': location, 'appid': api_key, 'units': 'metric'}, timeout=8
        )
        if resp.status_code != 200:
            return None, f'Weather API error: {resp.status_code} {resp.text[:120]}'
        j = resp.json()
        weather = {
            'name': j.get('name') or location,
            'country': (j.get('sys') or {}).get('country'),
            'temp': (j.get('main') or {}).get('temp'),
            'feels_like': (j.get('main') or {}).get('feels_like'),
            'humidity': (j.get('main') or {}).get('humidity'),
            'wind_speed': (j.get('wind') or {}).get('speed'),
            'condition': (j.get('weather') or [{}])[0].get('main'),
            'description': (j.get('weather') or [{}])[0].get('description'),
            'icon': (j.get('weather') or [{}])[0].get('icon'),
        }
        return weather, None
    except Exception as e:
        return None, f'Weather fetch failed: {e}'


def base_essentials(days: int):
    # quantities scaled by days
    tops = max(2, math.ceil(days * 0.7))
    bottoms = max(1, math.ceil(days / 3))
    underwear = days + 2
    socks = max(2, days)
    return {
        'Clothing': [
            ('T-shirt', tops),
            ('Shirt/Top', max(0, tops - 1)),
            ('Jeans/Trousers', bottoms),
            ('Shorts', 1 if days >= 2 else 0),
            ('Underwear', underwear),
            ('Socks', socks),
            ('Sleepwear', 1),
        ],
        'Footwear & Accessories': [
            ('Walking Shoes', 1),
            ('Belt', 1),
            ('Cap/Hat', 1),
            ('Sunglasses', 1),
        ],
        'Toiletries': [
            ('Toothbrush', 1),
            ('Toothpaste', 1),
            ('Shampoo/Conditioner', 1),
            ('Soap/Body Wash', 1),
            ('Deodorant', 1),
            ('Razor/Trimmer', 1),
            ('Skincare', 1),
            ('Makeup/Remover', 1),
            ('Sanitizer/Wipes', 1),
            ('Tissues', 1),
        ],
        'Health & Safety': [
            ('Medications', 1),
            ('First-aid (Band-aids etc.)', 1),
            ('Travel Insurance', 1),
        ],
        'Documents & Money': [
            ('Government ID', 1),
            ('Travel Tickets', 1),
            ('Cash & Cards', 1),
        ],
        'Electronics': [
            ('Phone + Charger', 1),
            ('Power Bank', 1),
            ('Cables/USB', 1),
        ],
        'Bags & Misc': [
            ('Backpack/Daypack', 1),
            ('Packing Cubes', 1),
            ('Luggage Locks', 1),
            ('Reusable Bottle', 1),
            ('Towel/Quick-dry', 1),
            ('Snacks', 1),
        ]
    }


def weather_adjustments(weather: dict, trip_type: str):
    additions = {k: [] for k in ['Clothing', 'Footwear & Accessories', 'Toiletries']}
    if not weather:
        # If weather unavailable, suggest general items
        additions['Clothing'] += [('Jacket/Coat', 1)]
        additions['Footwear & Accessories'] += [('Umbrella', 1), ('Sunscreen (SPF 30+)', 1)]
        return additions

    temp = weather.get('temp')
    cond = (weather.get('condition') or '').lower()
    desc = (weather.get('description') or '').lower()

    is_rain = 'rain' in cond or 'rain' in desc or 'drizzle' in desc
    is_snow = 'snow' in cond or 'snow' in desc
    is_cold = temp is not None and temp < 15
    is_hot = temp is not None and temp > 30

    if is_cold:
        additions['Clothing'] += [('Jacket/Coat', 1), ('Sweater/Hoodie', 1), ('Scarf', 1), ('Gloves', 1)]
        additions['Footwear & Accessories'] += [('Boots', 1)]
    if is_hot or trip_type in ['beach']:
        additions['Clothing'] += [('Swimwear', 1)]
        additions['Footwear & Accessories'] += [('Flip-flops', 1), ('Cap/Hat', 1), ('Sunglasses', 1)]
        additions['Toiletries'] += [('Sunscreen (SPF 30+)', 1)]
    if is_rain:
        additions['Clothing'] += [('Raincoat/Poncho', 1)]
        additions['Footwear & Accessories'] += [('Umbrella', 1)]
    if is_snow:
        additions['Clothing'] += [('Jacket/Coat', 1), ('Sweater/Hoodie', 1), ('Scarf', 1), ('Gloves', 1)]
        additions['Footwear & Accessories'] += [('Boots', 1)]

    return additions


def trip_type_addons(trip_type: str):
    addons = {k: [] for k in ['Clothing', 'Footwear & Accessories', 'Documents & Money', 'Electronics', 'Bags & Misc']}
    t = (trip_type or '').lower()
    if t == 'business':
        addons['Clothing'] += [('Shirt/Top', 1), ('Dress', 1)]
        addons['Footwear & Accessories'] += [('Dress Shoes/Heels', 1)]
        addons['Electronics'] += [('Laptop/Tablet + Charger', 1)]
    if t == 'beach':
        addons['Clothing'] += [('Swimwear', 1), ('Shorts', 1)]
        addons['Footwear & Accessories'] += [('Flip-flops', 1), ('Cap/Hat', 1)]
    if t == 'hiking':
        addons['Footwear & Accessories'] += [('Boots', 1), ('Cap/Hat', 1)]
        addons['Bags & Misc'] += [('Reusable Bottle', 1)]
    if t == 'wedding':
        addons['Clothing'] += [('Dress', 1)]
        addons['Footwear & Accessories'] += [('Jewelry (minimal)', 1), ('Dress Shoes/Heels', 1)]
    if t == 'international':
        addons['Documents & Money'] += [('Passport', 1), ('Visa/Itinerary', 1)]
        addons['Electronics'] += [('Universal Adapter', 1)]
    # leisure is covered by base
    return addons


def merge_categories(cat_a: dict, cat_b: dict):
    out = {}
    keys = set(cat_a.keys()) | set(cat_b.keys())
    for k in keys:
        out[k] = []
        items = {}
        for name, qty in cat_a.get(k, []) + cat_b.get(k, []):
            items[name] = items.get(name, 0) + (qty or 0)
        out[k] = [(n, q) for n, q in items.items() if q > 0]
    return out


def build_packing_list(location: str, days: int, trip_type: str, weather: dict):
    base = base_essentials(days)
    weather_add = weather_adjustments(weather, trip_type)
    trip_add = trip_type_addons(trip_type)

    # Merge progressively
    merged = merge_categories(base, weather_add)
    merged = merge_categories(merged, trip_add)

    # Sort items alphabetically in each category for nice UI
    for k in list(merged.keys()):
        merged[k] = sorted(merged[k], key=lambda x: x[0].lower())

    return merged


@app.route('/')
def index():
    return render_template('index.html', trip_types=TRIP_TYPES)


@app.route('/planner', methods=['POST'])
def planner():
    location = request.form.get('location', '').strip()
    days = int(request.form.get('days', '4') or 4)
    trip_type = request.form.get('trip_type', 'leisure')

    weather, werr = fetch_weather(location) if location else (None, None)
    items = build_packing_list(location, days, trip_type, weather)

    return render_template(
        'planner.html',
        location=location or 'Your Trip',
        days=days,
        trip_type=trip_type,
        weather=weather,
        weather_error=werr,
        items=items,
        ICON_MAP=ICON_MAP
    )


@app.route('/pdf')
def pdf():
    # Accept query params
    location = request.args.get('location', 'Your Trip')
    days = int(request.args.get('days', '4') or 4)
    trip_type = request.args.get('trip_type', 'leisure')
    weather, _ = fetch_weather(location)

    items = build_packing_list(location, days, trip_type, weather)

    # Generate PDF in-memory
    buf = BytesIO()
    c = canvas.Canvas(buf, pagesize=A4)
    width, height = A4

    # Title
    c.setFillColor(colors.HexColor('#0f172a'))
    c.setFont('Helvetica-Bold', 20)
    c.drawString(20*mm, height - 20*mm, 'AI Travel Luggage Planner')

    c.setFont('Helvetica', 12)
    c.setFillColor(colors.black)
    c.drawString(20*mm, height - 27*mm, f'Location: {location}  |  Days: {days}  |  Trip: {trip_type.title()}')

    y = height - 35*mm
    if weather:
        wtext = f"Weather: {weather.get('name','')}, {weather.get('country','')}  {weather.get('temp','?')}°C, {weather.get('description','').title()}"
        c.drawString(20*mm, y, wtext)
        y -= 8*mm

    # Draw categories & items
    for cat, lst in items.items():
        if y < 30*mm:
            c.showPage()
            y = height - 20*mm
        c.setFont('Helvetica-Bold', 14)
        c.setFillColor(colors.HexColor('#334155'))
        c.drawString(20*mm, y, cat)
        y -= 6*mm
        c.setFont('Helvetica', 11)
        c.setFillColor(colors.black)
        for name, qty in lst:
            if y < 20*mm:
                c.showPage()
                y = height - 20*mm
                c.setFont('Helvetica', 11)
            # checkbox
            c.rect(20*mm, y-3.5*mm, 5*mm, 5*mm)
            c.drawString(27*mm, y, f"{name}  x{qty}")
            y -= 6.5*mm
        y -= 3*mm

    c.showPage()
    c.save()

    buf.seek(0)
    filename = f"planner_{location.replace(' ', '_')}.pdf"
    return send_file(buf, as_attachment=True, download_name=filename, mimetype='application/pdf')


if __name__ == '__main__':
    app.run(debug=True)
