# ✈️ AI Travel Luggage Planner (Python + Flask)

A beautiful, **AI-style packing list generator** with **live weather**, **responsive UI**, **animated icons**, **voice input**, and **PDF download**.

## Features
- 🌦️ **Weather-aware**: Uses OpenWeatherMap to tailor items (jacket, umbrella, sunscreen, etc.)
- 📱 **Mobile‑responsive** UI with animated icons and clean cards
- 🗣️ **Voice input** for destination (Web Speech API), and **Read Aloud** for the list
- 🧾 **One‑click PDF** checklist export
- 🧳 **Smart suggestions** by **days** and **trip type** (leisure, business, beach, hiking, wedding, international)
- 🖼️ Built‑in icons and background (no external assets needed)

## Quick Start

### 1) Clone & Create a Virtual Env
```bash
python -m venv .venv
source .venv/bin/activate  # Windows: .venv\Scripts\activate
```

### 2) Install Dependencies
```bash
pip install -r requirements.txt
```

### 3) Add Weather API Key
Create a `.env` file and put your OpenWeatherMap API key:
```
OPENWEATHER_API_KEY=YOUR_KEY
```
Get a free key at https://openweathermap.org/api

### 4) Run
```bash
python app.py
```
Then open http://127.0.0.1:5000 in your browser.

## How it Works
- The app fetches current weather for your destination and adjusts the packing list.
- Base essentials scale with **number of days** (e.g., underwear, tops, socks) and add-ons for **trip type**.
- Download a formatted PDF checklist.

## Customization Tips
- Add or modify items in `app.py` (see `ICON_MAP`, `base_essentials`, `trip_type_addons`)
- Add more icons under `static/icons/` and map them in `ICON_MAP`
- Tweak styles in `static/css/style.css`

## Troubleshooting
- **No weather shown?** Ensure `OPENWEATHER_API_KEY` is set and valid.
- **Speech not working?** Web Speech API may require Chrome/Edge and HTTPS.
- **Port already used?** Change the Flask port in `app.py` (e.g., `app.run(port=5050)`).

---
Made with ❤ for smoother trips.
