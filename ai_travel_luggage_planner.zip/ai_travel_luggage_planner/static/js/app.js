(function(){
  // Voice input for location
  const mic = document.getElementById('micBtn');
  const loc = document.getElementById('location');
  if (mic && ('webkitSpeechRecognition' in window || 'SpeechRecognition' in window)) {
    const SR = window.SpeechRecognition || window.webkitSpeechRecognition;
    const rec = new SR();
    rec.lang = 'en-IN';
    rec.interimResults = false;
    rec.maxAlternatives = 1;

    mic.addEventListener('click', () => {
      try { rec.start(); } catch(e) {}
      mic.classList.add('listening');
    });
    rec.onresult = (e) => {
      const said = e.results[0][0].transcript;
      if (loc) loc.value = said;
    };
    rec.onend = () => { mic.classList.remove('listening'); };
  } else if (mic) {
    mic.style.display = 'none';
  }

  // Read aloud packing list
  const readBtn = document.getElementById('readBtn');
  if (readBtn && 'speechSynthesis' in window) {
    readBtn.addEventListener('click', () => {
      const items = Array.from(document.querySelectorAll('.item .txt')).map(el => el.textContent.trim());
      if (!items.length) return;
      const msg = new SpeechSynthesisUtterance('Here is your packing list: ' + items.join(', '));
      msg.lang = 'en-IN';
      msg.rate = 1.0; msg.pitch = 1.0; msg.volume = 1.0;
      window.speechSynthesis.cancel();
      window.speechSynthesis.speak(msg);
    });
  } else if (readBtn) {
    readBtn.style.display = 'none';
  }
})();
